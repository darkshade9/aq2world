The Action Quake 2 Map Depot - 3/03/2002
----------------------------------------

Ambient Sound Pack #1
=====================

The sounds in this ZIP file were downloaded from www.partnersinrhyme.com
and zipped by MP*Idle.
They can be distributed freely.
=====================

Filename             Size   Description
----------------   ------   -----------
crowdboo.wav        47 KB   Bunch of people yelling boo
crowdyay.wav        53 KB   The crowd's gone wild and celebrates
hurricane.wav       50 KB   Ah yes, the hurricanes are blowing tonight
jungle.wav         103 KB   Welcome to the jungle, baby!
newyears.wav        56 KB   It's New Year's eve...
oceansea.wav        84 KB   Sitting at the seashore, watching the seagulls?
rainthunder.wav    120 KB   Just the sound I needed for my stormy weathers map!
river.wav           80 KB   By the river of Babylon...
trainstation.wav    61 KB   Choo! Choo! Ah damn, there goes nothing.
-----------

The Action Quake 2 Map Depot - aqmd.action-web.net
The Action Message Boards    - www.aq2zone.com