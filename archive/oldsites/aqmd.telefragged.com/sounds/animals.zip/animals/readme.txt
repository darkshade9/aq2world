The Action Quake 2 Map Depot - 3/03/2002
----------------------------------------

Animal Sound Pack #1
=====================

The sounds in this ZIP file were downloaded from www.partnersinrhyme.com
and zipped by MP*Idle.
They can be distributed freely.
=====================

Filename        Size   Description
------------   -----   -----------
bird1.wav      15 KB   Ah bird.
bird2.wav       6 KB   Another bird.
bird3.wav      17 KB   Even more birds!
cat.wav        16 KB   Meow ... feed me!
chicken1.wav   11 KB   Chicken.
chicken2.wav   12 KB   Another chicken.
chicken3.wav   28 KB   The last chicken.
chimp1.wav     12 KB   Chimpanzee?
chimp2.wav     13 KB   Another chimpanzee???
cow.wav        37 KB   Moooo...
dog.wav        16 KB   Who let the dog out?!
frog.wav        6 KB   Ribbit!
goat.wav       21 KB   Baaaa... I'm a goat!
growlbar.wav   12 KB   Grrrr wooof!
horse.wav      24 KB   Look! A horse!
horsegal.wav   33 KB   A horse gallopping.
horseslo.wav   11 KB   Uhm ... a horse.
howl.wav       80 KB   Weird howling...
howl2.wav      33 KB   Even weirder.
hyenas.wav     58 KB   Remember The Lion King?
lion.wav       45 KB   Simba! The lion, that is.
madbark.wav    10 KB   Mad dog.
meeow.wav      10 KB   Meeeoooooww... I'm a cat?
monster.wav    17 KB   A hideous monster, indeed!
pant.wav       45 KB   Eh, something's panting...
pig1.wav       13 KB   Oink! Oink!
pig2.wav       17 KB   Another pig.
quicadog.wav    7 KB   Woof!
rooster1.wav   35 KB   A rooster...
rooster2.wav   32 KB   Another rooster.
tiger1.wav     14 KB   Meow! I'm a tiger!
tiger2.wav     36 KB   I'm a tiger too!
whale.wav      42 KB   A whale... beautiful sound.
yap.wav        10 KB   No idea!
==================================


The Action Quake 2 Map Depot - aqmd.action-web.net
The Action Message Boards    - www.aq2zone.com