The Action Quake 2 Map Depot - 3/11/2002
----------------------------------------

Miscellaneous Sound Pack #2
=====================

The sounds in this ZIP file were downloaded from various sites
and zipped by MP*Idle.
They can be distributed freely.
=====================

Filename                   Size   Description
----------------------   ------   -----------   
accessgranted.wav         38 KB   Access granted!
alarmclockbeep.wav       160 KB   Beep! Beep! Beep!
balloonstretchsnap.wav    29 KB   Balloon?!
blackholeclose.wav        44 KB   Very funny Scotty! Now beam down my clothes!
dream.wav                 18 KB   Dream, dream, dream...
eatcookie.wav             39 KB   *crunch* *crunch*
jarlidtwist.wav           64 KB   Well... a jar lid.
punch1.wav                 4 KB   Ouch!
punch2.wav                 4 KB   Oof!
punch3.wav                 4 KB   Gah!
punch4.wav                 4 KB   Ugh...
punch5.wav                 5 KB   Ahh!
pushpin.wav               22 KB   Eh...
rockdoor.wav              46 KB   No idea.
smallchime2.wav           33 KB   Chimes.
spurssteps4.wav           52 KB   Cowboys are coming to town!
timemachine.wav          164 KB   Back to the future?
toasterpopup.wav          33 KB   Mmm... I'm hungry.
-----------------------

The Action Quake 2 Map Depot - aqmd.action-web.net
The Action Message Boards    - www.aq2zone.com

