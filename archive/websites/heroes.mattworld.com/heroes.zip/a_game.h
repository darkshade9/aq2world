/*
 * Include for base Action game-related things
 */

#define ACTION_VERSION  "1.51 Heroes .81"

extern char team1_name[];
extern char team2_name[];
extern char team1_skin[];
extern char team2_skin[];
extern char team1_skin_index[];
extern char team2_skin_index[];
extern char *map_rotation[];
extern int num_maps, cur_map;
extern char *tnames[];

void ReadConfigFile();
void ReadSceneFile();
void ReadMOTDFile();
void PrintMOTD(edict_t *);
void stuffcmd(edict_t *, char *);

// Prototypes of base Q2 functions that weren't included in any Q2 header
qboolean loc_CanSee(edict_t *, edict_t *);
qboolean IsNeutral(edict_t *);
qboolean IsFemale(edict_t *);
void ParseSayText(edict_t *, char *);

// Firing styles (where shots originate from)
#define ACTION_FIRING_CENTER		0
#define ACTION_FIRING_CLASSIC		1
#define ACTION_FIRING_CLASSIC_HIGH	2
