
  These files must be here for Macintosh compability.

  If you are not using a Macintosh, then you may delete these files.

  This directory MAY be needed for Linux compatibility.

  If this is the case, you may delete all the files INSIDE of this 

  directory but you MUST keep the /pics/ directory present, even 

  though it is empty.  

