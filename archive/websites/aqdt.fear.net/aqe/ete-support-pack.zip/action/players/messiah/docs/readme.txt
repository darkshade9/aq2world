neo skin
------------
building time: about 2 hours
tools: qped, paint shop pro, adobe photoshop, JawMD2 viewer
author: red13

------------
Installation Instructions: Unzip into your x:/quake2/action/players/messiah/  directory


enjoy