The Action Quake 2 Map Depot - 3/11/2002
----------------------------------------

Miscellaneous Sound Pack #1
=====================

The sounds in this ZIP file were downloaded from various sites
and zipped by MP*Idle.
They can be distributed freely.
=====================

Filename                    Size   Description
-----------------------   ------   -----------   
backupbeep2.wav           103 KB   A truck.. stay out of it's way.
boxingbellmulti.wav        20 KB   Knock Out!
camel.wav                  18 KB   Never heard a camel before.
camerazoomout.wav          33 KB   A camera... zooming out.
chaching.wav               19 KB   A cash register. Cha-ching!
chimeslarge.wav            98 KB   Chimes.
dialcellphone.wav         212 KB   Pick up... pick up!
dialphone.wav              93 KB   Dialing the IRS?
drillshort.wav             12 KB   Drill...
faucetwater.wav           108 KB   Go figure.
fireworkdisplay.wav       140 KB   New Years Eve or WW 2?
handbellchristmas.wav      87 KB   A bell.. christmas.
hohoho.wav                 27 KB   Santa is here!
keylock.wav                60 KB   Lock up your daughters!
keys.wav                   60 KB   Ah screw it, let them out!
officephone.wav            19 KB   Oh no! Is it the boss?
partyhorn.wav              57 KB   Cheers!
phonebusy.wav              56 KB   !#@ busy #$& again!
pianosmash.wav             17 KB   That can't be Beethoven.
poptop.wav                 11 KB   Hmm...
radiobeep.wav              13 KB   Beep?
rattlespray.wav            37 KB   Tsk tsk.
recordplayercrackle.wav   103 KB   *sccscrrtsscctss*
silvercoin.wav             14 KB   The queen of the silver dollar?
smallbell.wav              25 KB   Ding!
tapetearoff.wav             6 KB   Groovy.
trumpet.wav                62 KB   Du-duuuuu!
walksidewalk.wav          178 KB   I'm walking...
woodchipper.wav           233 KB   No, not that tree!
-----------------------

The Action Quake 2 Map Depot - aqmd.action-web.net
The Action Message Boards    - www.aq2zone.com