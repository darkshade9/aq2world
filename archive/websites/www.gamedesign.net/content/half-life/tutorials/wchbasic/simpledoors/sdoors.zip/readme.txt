Simple Doors.
A tutorial for RUST http://www.gamedesign.net/
--------------------------------------------------------------------------------------------------------------------
Description:
Example map for WorldCraft/Hammer in two formats.

Contents:
readme.txt	This file
sdoors.map	Map in .map format
sdoors.rmf	WorldCraft/Hammer map

Note: It's better to use the .rmf file in WorldCraft 

The tutorial itself can be found in the Half-Life Tutorials Worldcraft Hammer editing section of RUST
--
Website: http://www.gamedesign.net