In the Beginning 6: Monsters Tutorial Example Files

Description:
Example map for WorldCraft in two formats.

Contents:
readme.txt	This file
beginning6.map	Map in .map format
beginning6.rmf	WorldCraft map
beginning6.bsp	Compiled BSP ready for playing
test.map	              Map in .map format
test.rmf	              WorldCraft map
test.bsp	              Compiled BSP ready for playing
infonode.txt	Extract from old WC manual - tips

Note: It's better to use the .rmf file in WorldCraft 

The tutorial itself can be found in the Half-Life Tutorials Worldcraft Hammer editing
section of RUST

--
Website: http://www.gamedesign.net