Rope: Water and other stuff?

Description:
Example map for WorldCraft/Hammer in two formats.

Contents:

readme.txt	This file
rope.map	Map in .map format
rope.rmf	WorldCraft map
rope.bsp	Compiled BSP ready for playing

Note: It's better to use the .rmf file in WorldCraft 

The tutorial itself can be found in the Tutorials
section of http://twhl.cjb.net

--
Website: http://twhl.cjb.net 