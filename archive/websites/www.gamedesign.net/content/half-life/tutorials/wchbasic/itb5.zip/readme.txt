In the Beginning 5: Furniture Tutorial Example Files

Description:
Example map for WorldCraft in two formats.

Contents:
readme.txt	This file
beginning5.map	Map in .map format
beginning5.rmf	WorldCraft map
beginning5.bsp	Compiled BSP ready for playing

Note: It's better to use the .rmf file in WorldCraft 

The tutorial itself can be found in the Half-Life Tutorials, Worldcraft Hammer
Editing section of RUST

Website: http://www.gamedesign.net