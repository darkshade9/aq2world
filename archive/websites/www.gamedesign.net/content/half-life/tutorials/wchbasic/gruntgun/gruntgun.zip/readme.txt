Grunts and Guns Tutorial Example Files

Description:
Example map for WorldCraft in two formats.

Contents:
readme.txt	This file
gruntgun.map	Map in .map format
gruntgun.rmf	WorldCraft map
gruntgun.bsp	Compiled BSP ready for playing

Note: It's better to use the .rmf file in WorldCraft 

