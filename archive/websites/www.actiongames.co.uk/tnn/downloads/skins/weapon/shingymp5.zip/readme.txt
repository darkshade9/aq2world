Here is my Golden Mp5 Skin. Feel free to use it and too distribute it, but you must include
this text file. If you already have a pak6.pak, rename it to another one, that you don't
have. Have fun.

Shingy
http://aq2og.telefragged.com