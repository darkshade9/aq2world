Well I have no idea what to put in this file,
 or how to zip this file or whatever, so I took a good guess :)

Unzip and plave the skin.pcx in the g_cannon folder into the
"models/weapons/g_cannon" file in your pak0.pak file

and put the skin.pcx in the v_cannon folder into the
"models/weapons/v_cannon" file in yuor pak0.pak

Bothe made by PACMAN{SO}