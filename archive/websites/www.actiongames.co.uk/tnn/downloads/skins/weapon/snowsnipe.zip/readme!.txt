New scopes and skin for the SSG sniper rifle.

 This adds a new skin and new scopes.  The skin is a black and white camo used by military in snow missions or stealth missions.  the scope is a pic i made while acually looking through my $700 scope that is mounted on my robar rifle, it has somewhat of a nigh sight feel because it glows! I reccomend since the crosshairs dont touch to use the dot crosshair or none at all.  The reason they dont touch is because they dont touch in my real scope and it gives it better accuracy.  to install just unzip this to your quake2 dir and it will auto go in the right folders.  Made for clan Spec Ops.


Corn Pops