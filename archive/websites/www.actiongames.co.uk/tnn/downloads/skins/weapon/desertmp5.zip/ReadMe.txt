Mp5  Desert Camo skin.
look around in the actors guild to find installation instructions. Thx.

NoHoPe