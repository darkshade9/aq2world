-=<SpedDmn's Custom Sniper Rifle Sights>=-
Action Quake 2 Sniper Rifle Sights
------
By: Matt Thalken (SpedDmn[11])
e-mail: speddmn@clan11.com
Build Time: 1 hour give or take
version: 1.2
Tools used: Adobe Photoshop 5.0
Credits: The A-Team, do i need to tell you why? ID Software, p1mpest game o the year! And 
Kramed at the Action Quake 2 owners guide (aq2og.telefragged.com) because he put my work 
on his page when nobody else would.
------
Description: These are 3 sniper rifle sights for 2x, 4x, and 6x sniper rifle zooms in 
action quake2. Hope ya dig em, please give credit where credit is due if you re-distribute.
------
Installation Instructions: Just unzip into your AQ2 dir (ex: c:\games\quake2\action) 
and rename the pakx.pak to whatever number is free (for example of you have 
pak0.pak, pak1.pak and pak2.pak, you could rename it from pak3.pak to pak9.pak).
------