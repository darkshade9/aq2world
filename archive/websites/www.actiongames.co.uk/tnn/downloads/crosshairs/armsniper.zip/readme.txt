Just an alternative sniper crosshair.  I got the idea off some ad for a
in a magazine.  Anyway, unzip this into your x:\quake\action\ folder...rename armageddon.pak
to your next pak in sequence.  Anyone who enjoys this, please, send some feedback :).  Enjoy.
-- ]EA[Armageddon     