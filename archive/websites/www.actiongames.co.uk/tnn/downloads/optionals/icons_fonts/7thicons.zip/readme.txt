=================================
^V^7ths0n^'s funky icon things...
=================================

Credits: Me ME ME! oh, and the guy who did
the original icons for AQ2... you rock...

Details: Funky icon thingys that have 
transparent back things...

=====================================
Ok, so how the hell do i use these ?!
=====================================

Right, go to your Action directory and make
a directory called pics... then, simply 
extract the files from 7thicons.zip into that
folder, simple eh ?

basically they should sit in here:
c:\quake2\action\pics\
Just change that path to whatever is
relevant to your setup...

If that doesnt work then... well... er...
IT WORKS FOR ME DAMNIT@(*_)&*~(@_)~@*_~@()

=====================
Comments etc.etc.....
=====================

Please feel free to flame the hell out of the 
author at waaagh@portent.net

Im not responsible for any loss, damage, etc.etc
blah blah legal bullshit blah blah that may occur
as a result of using these icons....

============
Blatant plug
============

Come and play at BarrysWorld...
you know it makes sense...

rex.barrysworld.com:27891
norman.barrysworld.com:27890

Both running AQ2 teamplay (RAA!!)